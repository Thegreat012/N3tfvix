<?php

header("Location: https://toys-store.site");
exit();
?>
